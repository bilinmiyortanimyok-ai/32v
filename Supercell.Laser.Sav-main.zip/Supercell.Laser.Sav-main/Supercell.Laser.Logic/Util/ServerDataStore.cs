namespace Supercell.Laser.Server.Utils
{
    using System;
    using System.IO;
    using Newtonsoft.Json;

    public static class ServerDataStore
    {
        private static readonly object FileLock = new();
        private static string m_dataFilePath;
        private static ServerData m_data = new();

        public static void Init()
        {
            m_dataFilePath = ResolveDataFilePath();
            Load();
            Save();
            IncrementBuildVersionCompleted();
        }

        public static string GetServerVersion()
        {
            string serverVersion = $"v{m_data.MajorVersion}.{m_data.BuildVersion}.{m_data.MinorVersion}";
            return serverVersion;
        }

        public static int GetBattlesCompletedCount()
        {
            int battlesCount = m_data.BattlesCompleted;
            return battlesCount;
        }

        public static void IncrementBuildVersionCompleted()
        {
            lock (FileLock)
            {
                m_data.MinorVersion++;
                if (m_data.BuildVersion >= 99)
                {
                    m_data.MajorVersion++;
                    m_data.BuildVersion = 0;
                }
                if (m_data.MinorVersion >= 99)
                {
                    m_data.BuildVersion++;
                    m_data.MinorVersion = 0;
                }
                SaveLocked();
            }
        }

        public static void IncrementBattlesCompleted()
        {
            lock (FileLock)
            {
                m_data.BattlesCompleted++;
                SaveLocked();
            }
        }

        private static void Load()
        {
            lock (FileLock)
            {
                if (!File.Exists(m_dataFilePath))
                {
                    m_data = new ServerData();
                    return;
                }

                try
                {
                    string json = File.ReadAllText(m_dataFilePath);
                    m_data = JsonConvert.DeserializeObject<ServerData>(json) ?? new ServerData();
                }
                catch
                {
                    m_data = new ServerData();
                }
            }
        }

        private static void Save()
        {
            lock (FileLock)
            {
                SaveLocked();
            }
        }

        private static void SaveLocked()
        {
            string json = JsonConvert.SerializeObject(m_data, Formatting.Indented);
            File.WriteAllText(m_dataFilePath, json);
        }

        private static string ResolveDataFilePath()
        {
            string basePath = AppContext.BaseDirectory;
            string localPath = Path.Combine(basePath, "Data.json");
            string projectRoot = Path.GetFullPath(Path.Combine(basePath, "..", "..", ".."));
            string projectPath = Path.Combine(projectRoot, "Data.json");

            if (Directory.Exists(projectRoot))
            {
                return projectPath;
            }

            return localPath;
        }

        private class ServerData
        {
            [JsonProperty("battlesCompleted")]
            public int BattlesCompleted { get; set; }

            [JsonProperty("majorVersion")]
            public int MajorVersion { get; set; }

            [JsonProperty("buildVersion")]
            public int BuildVersion { get; set; }

            [JsonProperty("minorVersion")]
            public int MinorVersion { get; set; }
        }
    }
}
