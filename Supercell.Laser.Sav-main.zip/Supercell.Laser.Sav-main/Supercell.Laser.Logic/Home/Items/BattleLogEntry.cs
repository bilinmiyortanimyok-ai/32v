using Supercell.Laser.Logic.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using Supercell.Laser.Titan.DataStream;
using Newtonsoft.Json;
using System.Reflection.Metadata.Ecma335;
using System.Data;
using Supercell.Laser.Logic.Data;
using Supercell.Laser.Logic.Home.Gatcha;
using Supercell.Laser.Logic.Message.Home;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Reflection;
using Supercell.Laser.Logic.Home.Items;
using Supercell.Laser.Logic.Helper;
using Supercell.Laser.Logic.Battle.Structures;
using Supercell.Laser.Logic.Avatar.Structures;

namespace Supercell.Laser.Logic.Home.Items
{

    public class BattleLogPlayer
    {
        public long AccountId;
        public int TeamIndex;
        public int BrawlerId;
        public int BrawlerLevel;
        public int BrawlerTrophies;
        public int BattleRoyaleRank;
        public PlayerDisplayData DisplayData;

        public void Encode(ByteStream Stream)
        {
            Stream.WriteVInt(1);
            Stream.WriteLong(AccountId);
            Stream.WriteVInt(TeamIndex); // TeamIndex
            Stream.WriteBoolean(false); // StarPlayer
            ByteStreamHelper.WriteDataReference(Stream, BrawlerId);
            Stream.WriteVInt(0); // Brawler Trophies
            Stream.WriteVInt(1);
            Stream.WriteVInt(0);
            DisplayData.Encode(Stream);
        }
    }

    public class BattleLogStructure
    {

        public DateTime BattleLogCreateTimer { get; set; }
        public int BattleLogType { get; set; }
        public int TrophiesResult { get; set; }
        public int BattleTime { get; set; }
        public bool IsFriendly { get; set; }
        public int MapId { get; set; }
        public int Result { get; set; }
        public int Index { get; set; }
        public List<BattleLogPlayer> Players;

        public void Encode(ByteStream Stream)
        {
            Stream.WriteVInt(0);
            Stream.WriteVInt((int)(DateTime.UtcNow - BattleLogCreateTimer).TotalSeconds);
            Stream.WriteVInt(1); // GameMode
            Stream.WriteVInt(TrophiesResult); // Trophies
            Stream.WriteVInt(BattleTime); // BattleTime
            Stream.WriteBoolean(false); // friendly game
            ByteStreamHelper.WriteDataReference(Stream, MapId);
            Stream.WriteVInt(Result); // Victory/Defeat/Draw
            Stream.WriteVInt(0);

            Stream.WriteInt(0);
            Stream.WriteInt(0);
            Stream.WriteInt(0);
            Stream.WriteInt(0);

            Stream.WriteVInt(0);
            Stream.WriteBoolean(false);
            Stream.WriteVInt(Players.Count);
            foreach (BattleLogPlayer player in Players)
            {
                Stream.WriteVInt(1);
                Stream.WriteLong(player.AccountId);
                Stream.WriteVInt(player.TeamIndex); // TeamIndex
                Stream.WriteBoolean(false); // StarPlayer
                ByteStreamHelper.WriteDataReference(Stream, player.BrawlerId);
                Stream.WriteVInt(player.BrawlerTrophies); // Brawler Trophies
                Stream.WriteVInt(player.BrawlerLevel);
                Stream.WriteVInt(player.BattleRoyaleRank);
                player.DisplayData.Encode(Stream);
            }
            Stream.WriteVInt(0);
            Stream.WriteBoolean(false); // Power Play
            Stream.WriteVInt(-1);
            Stream.WriteBoolean(false);
            Stream.WriteVInt(0);
            Stream.WriteBoolean(false);
        }
    }

    public class BattleLog
    {
        [JsonProperty("battlelogs_list")]
        public List<BattleLogStructure> BattleLogsList;

        public BattleLog()
        {
            BattleLogsList = new List<BattleLogStructure>();
        }

        public void Add(BattleLogStructure log, int BattleLogType,int TrophiesResult, int BattleTime, bool IsFriendly, int MapId, int Result, List<BattleLogPlayer> Players)
        {
            log.Index = GetIndex();
            log.BattleLogCreateTimer = DateTime.UtcNow;
            log.BattleLogType = BattleLogType;
            log.TrophiesResult = TrophiesResult;
            log.BattleTime = BattleTime;
            log.IsFriendly = IsFriendly;
            log.MapId = MapId;
            log.Result = Result;
            log.Players = Players;
            BattleLogsList.Add(log);
            if (BattleLogsList.Count >= 25)
            {
                BattleLogsList.RemoveAt(0);
            }
        }

        public int GetIndex()
        {
            return BattleLogsList.Count;
        }

        public void Encode(ByteStream stream)
        {
            stream.WriteBoolean(true);

            if (BattleLogsList.Count < 26)
                stream.WriteVInt(BattleLogsList.Count);
            else
                stream.WriteVInt(25);

            for (int i = BattleLogsList.Count - 1; i >= 0; i--)
            {
                BattleLogStructure log = BattleLogsList[i];
                log.Encode(stream);
            }
        }
    }

}