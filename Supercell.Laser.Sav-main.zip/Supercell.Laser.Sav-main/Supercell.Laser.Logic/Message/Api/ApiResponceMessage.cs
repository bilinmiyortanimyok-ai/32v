namespace Supercell.Laser.Logic.Message.Api
{
    public class ApiResponceMessage : GameMessage
    {
        public string Message;

        public override void Encode()
        {
            Stream.WriteString(Message);
        }
        public override int GetMessageType()
        {
            return 21999;
        }

        public override int GetServiceNodeType()
        {
            return 1;
        }
    }
}