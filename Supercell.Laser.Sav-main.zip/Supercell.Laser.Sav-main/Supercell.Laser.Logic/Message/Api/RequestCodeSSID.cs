namespace Supercell.Laser.Logic.Message.Api
{
    public class RequestCodeSSID : GameMessage
    {
        public string AuthPass;
        public string AccountTag;

        public override void Decode()
        {
            AuthPass = Stream.ReadString();
            AccountTag = Stream.ReadString();
        }
        public override int GetMessageType()
        {
            return 19995;
        }

        public override int GetServiceNodeType()
        {
            return 1;
        }
    }
}
