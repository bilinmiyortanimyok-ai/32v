namespace Supercell.Laser.Logic.Message.Api
{
    public class SynsCodeSSIDResponce : GameMessage
    {
        public int code;

        public override void Encode()
        {
            Stream.WriteInt(code);
        }
        public override int GetMessageType()
        {
            return 25000;
        }

        public override int GetServiceNodeType()
        {
            return 1;
        }
    }
}
