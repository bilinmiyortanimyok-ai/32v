﻿namespace Supercell.Laser.Logic.Message.Team
{
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Logic.Helper;
    
    public class TeamSetLocationMessage : GameMessage
    {
        public int LocationId;

        public override void Decode()
        {
            LocationId = ByteStreamHelper.ReadDataReference(Stream);
        }

        public override int GetMessageType()
        {
            return 14363;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
