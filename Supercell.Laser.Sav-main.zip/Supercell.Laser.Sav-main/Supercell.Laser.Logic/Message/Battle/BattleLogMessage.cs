namespace Supercell.Laser.Logic.Message.Battle
{
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home.Quest;
    using Supercell.Laser.Logic.Home;

    public class BattleLogMessage : GameMessage
    {
        public BattleLog BattleLog;

        public BattleLogMessage() : base()
        {
            ;
        }

        public override void Encode()
        {
            BattleLog.Encode(Stream);
            /*Stream.WriteVInt(5);
            for (int BattleLogs = 0; BattleLogs < 5; BattleLogs++)
            {
                Stream.WriteVInt(0);
                Stream.WriteVInt(0);
                Stream.WriteVInt(1); // GameMode
                Stream.WriteVInt(8); // Trophies
                Stream.WriteVInt(120); // BattleTime
                Stream.WriteBoolean(false); // friendly game
                Stream.WriteVInt(15); Stream.WriteVInt(7);
                Stream.WriteVInt(0); // Victory/Defeat/Draw
                Stream.WriteVInt(0);

                Stream.WriteInt(0);
                Stream.WriteInt(0);
                Stream.WriteInt(0);
                Stream.WriteInt(0);

                Stream.WriteVInt(0);
                Stream.WriteBoolean(false);
                Stream.WriteVInt(6);
                for (int players = 0; players < 6; players++) {
                    int TeamIndex = 0;
                    if (players > 2) {
                        TeamIndex = 1;
                    }
                    Stream.WriteVInt(1);
                    Stream.WriteInt(0); Stream.WriteInt(11 + players);
                    Stream.WriteVInt(TeamIndex); // TeamIndex
                    Stream.WriteBoolean(false); // StarPlayer
                    Stream.WriteVInt(16); Stream.WriteVInt(0);
                    Stream.WriteVInt(0); // Brawler Trophies
                    Stream.WriteVInt(1);
                    Stream.WriteVInt(0);
                    Stream.WriteString("SVO");
                    Stream.WriteVInt(100);
                    Stream.WriteVInt(28000000);
                    Stream.WriteVInt(43000000);
                    Stream.WriteVInt(46000000);
                }
                Stream.WriteVInt(0);
                Stream.WriteBoolean(false); // Power Play
                Stream.WriteVInt(-1);
                Stream.WriteBoolean(false);
                Stream.WriteVInt(0);
                Stream.WriteBoolean(false);
            }*/
        }

        public override int GetMessageType()
        {
            return 23458;
        }

        public override int GetServiceNodeType()
        {
            return 27;
        }
    }
}
