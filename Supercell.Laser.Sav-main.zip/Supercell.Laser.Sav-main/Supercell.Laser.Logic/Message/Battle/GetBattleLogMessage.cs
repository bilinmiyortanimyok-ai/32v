namespace Supercell.Laser.Logic.Message.Battle
{
    using Supercell.Laser.Logic.Battle;

    public class GetBattleLogMessage : GameMessage
    {
        public override void Decode()
        {
            ;
        }

        public override int GetMessageType()
        {
            return 14114;
        }

        public override int GetServiceNodeType()
        {
            return 27;
        }
    }
}
