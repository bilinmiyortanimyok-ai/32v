namespace Supercell.Laser.Logic.Message.Home
{
    public class SetSupportedCreatorResponseMessage : GameMessage
    {
        public string ContentCreator;

        public override void Encode()
        {
            Stream.WriteVInt(1);
            Stream.WriteString(null);
        }

        public override int GetMessageType()
        {
            return 28686;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
