namespace Supercell.Laser.Logic.Message.Home
{
    public class SetSupportedCreatorMessage : GameMessage
    {
        public string ContentCreator { get; set; }

        public override void Decode()
        {
            ContentCreator = Stream.ReadString();
        }

        public override int GetMessageType()
        {
            return 18686;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
