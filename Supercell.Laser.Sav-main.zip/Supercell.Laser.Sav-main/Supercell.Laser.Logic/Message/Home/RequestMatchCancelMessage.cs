namespace Supercell.Laser.Logic.Message.Home
{
    public class RequestMatchCancelMessage : GameMessage
    {
        public RequestMatchCancelMessage() : base()
        {

        }

        public override void Decode()
        {
            ;
        }

        public override int GetMessageType()
        {
            return 14117;
        }

        public override int GetServiceNodeType()
        {
            return 9;
        }
    }
}
