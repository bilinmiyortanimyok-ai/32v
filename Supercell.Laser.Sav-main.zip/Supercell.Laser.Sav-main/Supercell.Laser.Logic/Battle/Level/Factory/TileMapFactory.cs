﻿using System.IO;

namespace Supercell.Laser.Logic.Battle.Level.Factory
{
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Titan.Json;
    using Supercell.Laser.Titan.Util;
    using System.Text;

    public static class TileMapFactory
    {
        private static LogicJSONObject jsonObject = LogicJSONParser.ParseObject(File.ReadAllText("Assets/tilemaps.json"));

        public static TileMap CreateTileMap(string mapName)
        {
            LogicJSONObject obj = jsonObject.GetJSONObject(mapName);
            return new TileMap(obj.GetJSONNumber("Width").GetIntValue(),
                                    obj.GetJSONNumber("Height").GetIntValue(),
                                    obj.GetJSONString("Data").GetStringValue());
        }
        public static TileMap CreatePlayerMap(byte[] compressed)
        {
            return null;
        }

        public static void PrintAllTiles(string mapName)
        {
            return;
            try
            {
                string[] map = MapLoader.InitWithMapFromDataTable(null, DataTables.Get(19), mapName);

                if (map == null || map.Length == 0)
                {
                    // Console.WriteLine("Map not found or map is null!");
                    return;
                }

                // Console.WriteLine($"MapNme '{mapName}':");
                // Console.WriteLine($"Length: {map[0].Length}x{map.Length}");
                // Console.WriteLine("----------------------------------");

                for (int y = 0; y < map.Length; y++)
                {
                    for (int x = 0; x < map[y].Length; x++)
                    {
                        Console.Write(map[y][x] + " ");
                    }
                    // Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
        }
    }
}
