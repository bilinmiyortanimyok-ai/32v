﻿namespace Supercell.Laser.Logic.Battle.Objects
{
    using Supercell.Laser.Logic.Battle.Level;
    using Supercell.Laser.Logic.Battle.Structures;
    using Supercell.Laser.Logic.Data.Helper;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Math;
    using Supercell.Laser.Logic.Util;

    public class GameObjectManager // +32 type 64 encode 48IsAlive
    {
        public Queue<GameObject> AddObjects;
        private Queue<GameObject> RemoveObjects;

        private BattleMode Battle;
        public List<GameObject> GameObjects;
        public List<Petrol> Petrols;

        private int ObjectCounter;
        public int Ended = -1;

        public GameObjectManager(BattleMode battle)
        {
            Battle = battle;
            GameObjects = new List<GameObject>();
            Petrols = new List<Petrol>();

            AddObjects = new Queue<GameObject>();
            RemoveObjects = new Queue<GameObject>();
        }

        public GameObject[] GetGameObjects()
        {
            return GameObjects.ToArray();
        }
        public Projectile[] GetProjectiles()
        {
            List<Projectile> objects = new List<Projectile>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj != null && obj.GetObjectType() == 1)
                {
                    objects.Add((Projectile)obj);
                }
            }
            return objects.ToArray();
        }

        public Character[] GetCharacters()
        {
            List<Character> objects = new List<Character>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj != null && obj.GetObjectType() == 0)
                {
                    objects.Add((Character)obj);
                }
            }
            foreach (GameObject obj in AddObjects)
            {
                if (obj != null && obj.GetObjectType() == 0)
                {
                    objects.Add((Character)obj);
                }
            }
            return objects.ToArray();
        }

        public Item[] GetItems()
        {
            List<Item> objects = new List<Item>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj.GetObjectType() == 3)
                {
                    objects.Add((Item)obj);
                }
            }
            foreach (GameObject obj in AddObjects)
            {
                if (obj != null && obj.GetObjectType() == 3)
                {
                    objects.Add((Item)obj);
                }
            }
            return objects.ToArray();
        }

        public AreaEffect[] GetAreaEffects()
        {
            List<AreaEffect> objects = new List<AreaEffect>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj != null && obj.GetObjectType() == 2)
                {
                    objects.Add((AreaEffect)obj);
                }
            }
            foreach (GameObject obj in AddObjects)
            {
                if (obj != null && obj.GetObjectType() == 2)
                {
                    objects.Add((AreaEffect)obj);
                }
            }
            return objects.ToArray();
        }

        public Projectile[] GetSpecificProjectiles(GameObject gameObject)
        {
            List<Projectile> objects = new List<Projectile>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj != null && obj.GetObjectType() == 1 && obj.GetIndex() / 16 != gameObject.GetIndex() / 16 && obj.GetPosition().GetDistance(gameObject.GetPosition()) <= 600)
                {
                    objects.Add((Projectile)obj);
                }
            }
            return objects.ToArray();
        }

        public BattleMode GetBattle()
        {
            return Battle;
        }

        public void PreTick()
        {
            for (int i = 0; i < GameObjects.Count; i++)
            {

                GameObject gameObject = GameObjects[i];
                if (gameObject == null)
                {
                    GameObjects.Remove(gameObject);
                    i--;
                    continue;
                }
                if (gameObject.ShouldDestruct())
                {
                    gameObject.OnDestruct();
                    RemoveGameObject(gameObject);
                }
                else
                {
                    gameObject.ResetEventsOnTick();
                }
            }

            while (AddObjects.Count > 0)
            {
                GameObjects.Add(AddObjects.Dequeue());
            }
            for (int i = 0; i < GameObjects.Count; i++)
            {
                GameObject gameObject = GameObjects[i];
                if (gameObject == null)
                {
                    GameObjects.Remove(gameObject);
                    i--;
                    continue;
                }
            }
            while (RemoveObjects.Count > 0)
            {
                GameObjects.Remove(RemoveObjects.Dequeue());
            }
        }

        public Character FindObject(string name)
        {
            foreach (Character character in GetCharacters())
            {
                if (character.CharacterData.Name != name) return null;
                return character;
            }
            return null;
        }

        public void Tick()
        {
            {

                for (int i = 0; i < GameObjects.Count; i++)
                {
                    GameObject gameObject = GameObjects[i];
                    if (gameObject == null)
                    {
                        GameObjects.Remove(gameObject);
                        i--;
                        continue;
                    }
                    gameObject.Tick();
                }

            }
        }

        public void AddGameObject(GameObject gameObject)
        {
            if (gameObject != null)
            {
                gameObject.AttachGameObjectManager(this, GlobalId.CreateGlobalId(gameObject.GetObjectType(), ObjectCounter++));
                AddObjects.Enqueue(gameObject);
            }
        }

        public void RemoveGameObject(GameObject gameObject)
        {
            RemoveObjects.Enqueue(gameObject);
        }

        public GameObject GetGameObjectByID(int globalId)
        {
            GameObject gameObject = GameObjects.Find(obj => obj != null && obj.GetGlobalID() == globalId);
            if (gameObject == null) gameObject = AddObjects.ToList().Find(obj => obj != null && obj.GetGlobalID() == globalId);
            return gameObject;
        }

        public GameObject[] GetGameObjectsByID(int globalId)
        {
            List<GameObject> objects = new List<GameObject>();

            foreach (GameObject obj in GameObjects)
            {
                if (obj != null && obj.GetGlobalID() == globalId)
                {
                    objects.Add(obj);
                }
            }
            foreach (GameObject obj in AddObjects)
            {
                if (obj != null && obj.GetGlobalID() == globalId)
                {
                    objects.Add(obj);
                }
            }

            return objects.ToArray();
        }
        public List<GameObject> GetGameObjectByCloneOfObjectGlobalId(int globalId)
        {
            return GameObjects.FindAll(obj => obj.GetCloneOfObjectGlobalId() == globalId);
        }

        public List<GameObject> GetVisibleGameObjects(int teamIndex, int ownObjectGlobalId)
        {
            List<GameObject> objects = new List<GameObject>();
            try
            {
                bool IsInRealm = false;
                GameObject character = GetGameObjectByID(ownObjectGlobalId);
                if (character != null)
                {
                    IsInRealm = character.IsInRealm;
                }
                foreach (GameObject obj in GameObjects)
                {
                    if (obj.IsInRealm ^ IsInRealm) continue;
                    if (obj.GetFadeCounter() > 0 || obj.GetIndex() / 16 == teamIndex)
                    {
                        objects.Add(obj);
                    }
                }
                foreach (GameObject obj in AddObjects)
                {
                    try
                    {
                        if (obj == null)
                        {
                            Parallel.ForEach(GetBattle().m_players, player =>
                            {
                                if (player.GameListener != null)
                                {
                                    ;
                                }
                            });

                            GetBattle().m_updateTimer.Dispose();
                            GetBattle().IsGameOver = true;
                        }
                        if (obj == null) continue;
                        if (obj.IsInRealm ^ IsInRealm) continue;
                    }
                    catch (Exception ex)
                    {
                        Parallel.ForEach(GetBattle().m_players, player =>
                        {
                            if (player.GameListener != null)
                            {
                                ;
                            }
                        });

                        GetBattle().m_updateTimer.Dispose();
                        GetBattle().IsGameOver = true;

                    }
                    if (obj.GetFadeCounter() > 0 || obj.GetIndex() / 16 == teamIndex)
                    {
                        objects.Add(obj);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Battle stopped with exception! Message: " + e.Message + " Trace: " + e.StackTrace);

                GetBattle().m_updateTimer.Dispose();
                GetBattle().IsGameOver = true;
            }


            return objects;
        }

        public void Encode(BitStream bitStream, TileMap tileMap, int ownObjectGlobalId, int playerIndex, int teamIndex)
        {
            BattlePlayer[] players = Battle.GetPlayers();
            List<GameObject> visibleGameObjects = GetVisibleGameObjects(teamIndex, ownObjectGlobalId);

            int GameModeVariation = Battle.GetGameModeVariation();
            bitStream.WritePositiveInt(ownObjectGlobalId, 21);

            if (GameModeVariation == 0)
            {
                bitStream.WritePositiveVInt(Battle.GetGemGrabCountdown(), 4);
            }
            else if (GameModeVariation == 17)
            {
                bitStream.WritePositiveIntMax7(1); // if ( *(int *)(v246 + 456) >= 1 )
                {
                    bitStream.WritePositiveIntMax127(Battle.GetZone1Score());
                    bitStream.WritePositiveIntMax127(Battle.GetZone2Score());
                }
            }

            bitStream.WriteBoolean(false);
            bitStream.WriteInt(-1, 4);

            bitStream.WriteBoolean(true);
            bitStream.WriteBoolean(true);
            bitStream.WriteBoolean(true);
            bitStream.WriteBoolean(true);

            if (tileMap.Width < 22)
            {
                bitStream.WritePositiveInt(0, 5); // 0xa820a8
                bitStream.WritePositiveInt(0, 6); // 0xa820b4
                bitStream.WritePositiveInt(tileMap.Width - 1, 5); // 0xa820c0
            }
            else
            {
                bitStream.WritePositiveInt(0, 6); // 0xa820a8
                bitStream.WritePositiveInt(0, 6); // 0xa820b4
                bitStream.WritePositiveInt(tileMap.Width - 1, 6); // 0xa820c0
            }
            bitStream.WritePositiveInt(tileMap.Height - 1, 6); // 0xa820d0

            for (int i = 0; i < tileMap.Width; i++)
            {
                for (int j = 0; j < tileMap.Height; j++)
                {
                    var tile = tileMap.GetTile(i, j, true);
                    if (tile.Data.RespawnSeconds > 0 || tile.Data.IsDestructible || tile.Data.TileCode == "I")
                    {
                        //if (j == 13)
                        //{
                        //    bitStream.WriteBoolean(false);
                        //    continue;
                        //}
                        bitStream.WriteBoolean(tile.IsDestructed() && tileMap.GetTile(i, j, true).IsDestructed());
                    }
                }
            }

            bitStream.WritePositiveVIntMax65535OftenZero(0);

            bitStream.WritePositiveVIntMax65535OftenZero(Petrols.Count);
            if (Petrols.Count >= 1)
            {
                for (int i = 0; i < Petrols.Count; i++)
                {
                    bitStream.WritePositiveIntMax63(Petrols[i].X);
                    bitStream.WritePositiveIntMax63(Petrols[i].Y);
                    bitStream.WriteIntMax15(Petrols[i].TeamIndex);
                }
            }

            for (int i = 0; i < players.Length; i++)
            {
                bitStream.WriteBoolean(false);
                bitStream.WriteBoolean(players[i].HasUlti());
                if (GameModeVariation == 6) bitStream.WritePositiveIntMax15(0);
                if (GameModeVariation == 3) bitStream.WriteBoolean(false); // Blue Star

                bitStream.WriteBoolean(false);
                bitStream.WriteBoolean(players[i].IsUsingPin(GetBattle().GetTicksGone()));
                if (players[i].IsUsingPin(GetBattle().GetTicksGone()))
                {
                    bitStream.WriteIntMax7(players[i].PinIndex);
                    bitStream.WritePositiveIntMax16383(players[i].StartUsingPinTicks);
                }
                if (i == playerIndex)
                {
                    bitStream.WritePositiveIntMax4095(LogicMath.Clamp(players[i].GetUltiCharge(), 0,4000));
                    bitStream.WriteBoolean(false);
                    bitStream.WriteBoolean(false);
                }
            }

            bitStream.WritePositiveVIntMax255OftenZero(0);

            switch (GameModeVariation)
            {
                case 5:
                    bitStream.WriteBoolean(true);
                    bitStream.WriteIntMax1(1);
                    break;
                case 6:
                    bitStream.WritePositiveInt(Battle.GetPlayersAliveCountForBattleRoyale(), 4);
                    break;
                case 9:
                    bitStream.WritePositiveIntMax7(Battle.GetAliveTeams());
                    break;
                case 13:
                    bitStream.WritePositiveIntMax131071(0); // DMP
                    break;
                case 16:
                    bitStream.WritePositiveIntMax8191(0);
                    bitStream.WritePositiveIntMax8191(0);
                    break;
            }
            if (GameModeUtil.HasTwoBases(GameModeVariation))
            {
                int hp1 = 0;
                int hp2 = 0;
                foreach (Character character in GetCharacters())
                {
                    if (!character.CharacterData.IsBase()) continue;
                    if (!character.IsAlive()) continue;
                    if (character.GetIndex() / 16 == 0) hp1 = character.GetHitpointPercentage();
                    else hp2 = character.GetHitpointPercentage();
                }
                bitStream.WritePositiveIntMax127(hp1);
                bitStream.WritePositiveIntMax127(hp2);
            }

            for (int i = 0; i < players.Length; i++)
            {
                if (GameModeVariation != 6 && GameModeVariation != 9)
                {
                    bitStream.WriteBoolean(true);
                    bitStream.WritePositiveVIntMax255(players[i].GetScore());
                }
                else
                {
                    bitStream.WriteBoolean(false);
                }
                if (GameModeVariation != 6 && GameModeVariation != 9)
                {
                    if (bitStream.WriteBoolean(players[i].KillList.Count > 0))
                    {
                        bitStream.WritePositiveIntMax15(players[i].KillList.Count);
                        for (int j = 0; j < players[i].KillList.Count; j++)
                        {
                            bitStream.WritePositiveIntMax15(players[i].KillList[j].PlayerIndex);
                            bitStream.WriteIntMax7(players[i].KillList[j].BountyStarsEarned);
                        }
                    }
                }
                else
                {
                    bitStream.WriteBoolean(false);
                }
            }

            bitStream.WritePositiveVIntMax65535(visibleGameObjects.Count);

            foreach (GameObject gameObject in visibleGameObjects)
            {
                ByteStreamHelper.WriteDataReference(bitStream, gameObject.GetDataId());
            }

            foreach (GameObject gameObject in visibleGameObjects)
            {
                bitStream.WritePositiveVIntMax65535(GlobalId.GetInstanceId(gameObject.GetGlobalID())); // 0x2381b4
            }

            foreach (GameObject gameObject in visibleGameObjects)
            {
                gameObject.Encode(bitStream, gameObject.GetGlobalID() == ownObjectGlobalId, teamIndex);
            }
        }
    }
}
