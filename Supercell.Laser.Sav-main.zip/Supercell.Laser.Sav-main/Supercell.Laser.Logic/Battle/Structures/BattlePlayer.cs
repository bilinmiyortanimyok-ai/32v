﻿namespace Supercell.Laser.Logic.Battle.Structures
{
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Avatar;
    using Supercell.Laser.Logic.Avatar.Structures;
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Helper;
    using Supercell.Laser.Logic.Home;
    using Supercell.Laser.Logic.Home.Structures;
    using Supercell.Laser.Logic.Listener;
    using Supercell.Laser.Titan.DataStream;
    using Supercell.Laser.Titan.Math;
    using Supercell.Laser.Titan.Util;
    using Supercell.Laser.Logic.Battle.Objects;

    public class TickDamage
    {
        public int Tick { get; set; }
        public int Damage { get; set; }
    }
    public class BattlePlayer
    {
        public long AccountId;
        public int PlayerIndex;
        public int TeamIndex;
        public Dictionary<int, int> Emotes = new Dictionary<int, int>();
        public Dictionary<int, int> Spray = new Dictionary<int, int>();
        public long TeamId = -1;
        public int HeroIndex;
        public int HeroIndexMax;
        public PlayerDisplayData DisplayData;
        public int CharacterId => CharacterIds[HeroIndex];
        public int SkinId => SkinIds[HeroIndex];
        public long SessionId;
        public LogicGameListener GameListener;
        public int[] CharacterIds = new int[3];
        public int[] SkinIds = new int[3];
        public int OwnObjectId;
        public int PreviousObjectId;
        public int ControlTicksLeft;
        public int LastHandledInput;
        public int Trophies, HighestTrophies;
        public int HeroPowerLevel;
        private int Score;
        private LogicVector2 SpawnPoint;
        public bool RespawnStarted;
        public int RespawnX;
        public int RespawnY;
        public int StartUsingPinTicks;
        public int LastPinUseTicks;
        public int PinIndex;
        public int SprayIndex;
        public SkinConfData SkinConfData => SkinId == 0 ? null : DataTables.Get(DataType.SkinConf).GetData<SkinConfData>(DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(SkinId).Conf);
        public SkinData SkinData => SkinId == 0 ? null : DataTables.Get(DataType.Skin).GetDataByGlobalId<SkinData>(SkinId);
        public CardData AccessoryCardData => AccessoryCardDatas[HeroIndex];
        public CardData[] AccessoryCardDatas;
        public AccessoryData AccessoryData => AccessoryDatas[HeroIndex];
        public AccessoryData[] AccessoryDatas;
        public CardData StarPowerData => StarPowerDatas[HeroIndex];
        public CardData[] StarPowerDatas;
        public Accessory Accessory;
        public CharacterData CharacterData => CharacterDatas[HeroIndex];
        public CharacterData[] CharacterDatas;
        public CardData[] OverChargeDatas;
        public CardData OverChargeData => OverChargeDatas[HeroIndex];
        public int PowerLevel;
        public int Bot;
        public bool IsAdmin;
        private int UltiCharge;
        private int OverCharge;
        public bool OverCharging;
        public bool OverChargeActivated;
        public bool OverChargeStarted;
        public bool OverChargeEnded;
        public bool IsAlive;
        public int BattleRoyaleRank;
        public List<PlayerKillEntry> KillList;
        public int Kills;
        public int Damage;
        public int Heals;
        public int DeathTick;
        public int Deaths;
        public List<TickDamage> _damageHistory = new();
        public List<Item> BoMines = new();
        public bool HasStar;
        public int EventCollectTokens;
        public int TemporaryTeamOverride;
		public bool BattleEndSent;

        public BattlePlayer()
        {
            DisplayData = new PlayerDisplayData();
            SpawnPoint = new LogicVector2();

            StartUsingPinTicks = -9999;
            LastPinUseTicks = -9999;

            BattleRoyaleRank = -1;

            KillList = new List<PlayerKillEntry>();
            if (IsAdmin) UltiCharge = 4000;

            UltiCharge = 0;
            OverCharge = 0;
            DeathTick = 1;
        }
        public void Healed(int heals)
        {
            Heals += heals;
        }

        public int GetDps(Int64 a1 = 0)
        {
            return _damageHistory.Sum(d => d.Damage);
        }
        public void DamageDealed(int damage, int currentTick = 0)
        {
            Damage += damage;
            if (damage > 0)
            {
                _damageHistory.Add(new TickDamage { Tick = currentTick, Damage = damage });
            }
        }

        public int GetSprayIDBySprayIndex(int i)
        {
            return Spray[i];
        }

        public void KilledPlayer(int index, int bountyStars)
        {
            KillList.Add(new PlayerKillEntry()
            {
                PlayerIndex = index,
                BountyStarsEarned = bountyStars
            });

            Kills++;
        }

        public bool HasUlti()
        {
            return UltiCharge >= 4000;
        }

        public bool OverChargeReady()
        {
            return OverCharge >= 4000;
        }

        public int GetUltiCharge()
        {
            return UltiCharge;
        }

        public int GetOverCharge()
        {
            return OverCharge;
        }
        public int GetCardValueForPassive(string a2, int a3)
        {
            if (StarPowerData != null)
            {
                if (StarPowerData.Type == a2)
                {
                    if (a3 == 2) return StarPowerData.Value3;
                    return a3 > 0 ? StarPowerData.Value : StarPowerData.Value2;
                }
                else return -1;

            }
            else
                return -1;
        }
        public void AddUltiCharge(int amount)
        {
            UltiCharge = LogicMath.Clamp(UltiCharge + amount, 0, 4000);
        }
        public int GetGearBoost(int LogicType)
        {
            return 0;
        }
        public void ChargeUlti(int a2, bool a3, bool a4)
        {
            UltiCharge += a2;
        }

        public void UseUlti()
        {
            if (!IsAdmin) UltiCharge = 0;
            //UltiCharge = 0;
        }
        public int IsBot()
        {
            return Bot;
        }

        public BattlePlayer(ClientHome home, ClientAvatar avatar) : this()
        {
            Home = home;
            Avatar = avatar;
        }

        public void AddScore(int a)
        {
            Score += a;
        }

        public void ResetScore()
        {
            Score = 0;
        }

        public void UsePin(int index, int ticks)
        {
            StartUsingPinTicks = ticks;
            PinIndex = index;
            LastPinUseTicks = ticks;
        }

        public bool IsUsingPin(int ticks)
        {
            return ticks - StartUsingPinTicks < 80;
        }

        public void SetHeroIndex(int Index)
        {
            HeroIndex = Index;
           // Accessory = AccessoryDatas[Index] == null ? null : new Accessory(AccessoryDatas[Index]);

        }
        public int GetScore()
        {
            return Score;
        }

        public void SetSpawnPoint(int x, int y)
        {
            SpawnPoint.Set(x, y);
        }

        public void SetSpawnPoint(LogicVector2 pos)
        {
            SpawnPoint = pos;
        }

        public LogicVector2 GetSpawnPoint()
        {
            return SpawnPoint.Clone();
        }
        public bool HasOverCharge()
        {
            return OverChargeData != null;
        }

        public void Encode(ByteStream stream)
        {
            stream.WriteLong(AccountId);
            stream.WriteVInt(PlayerIndex);
            stream.WriteVInt(TeamIndex);
            stream.WriteVInt(0);
            stream.WriteInt(0);

            ByteStreamHelper.WriteDataReference(stream, CharacterId);
            ByteStreamHelper.WriteDataReference(stream, SkinIds[0]);
            stream.WriteBoolean(false);
            stream.WriteBoolean(false);
            DisplayData.Encode(stream);
            stream.WriteBoolean(false);
        }

        [JsonIgnore] public readonly ClientHome Home;
        [JsonIgnore] public readonly ClientAvatar Avatar;

        public static BattlePlayer Create(ClientHome home, ClientAvatar avatar, int playerIndex, int teamIndex)
        {
            BattlePlayer player = new BattlePlayer(home, avatar);
            player.DisplayData.Name = avatar.Name;
            player.DisplayData.ThumbnailId = home.ThumbnailId;
            player.DisplayData.NameColorId = home.NameColorId;
            if (avatar.Name.StartsWith("<c"))
            {
                player.DisplayData.HighNameColorId = -1;
            }
            else 
            {
                player.DisplayData.HighNameColorId = home.HasPremiumPass || home.NameColorId == 43000012 ? home.NameColorId : 0;
            }

            player.AccessoryCardDatas = new CardData[3];
            player.AccessoryDatas = new AccessoryData[3];
            player.StarPowerDatas = new CardData[3];
            player.CharacterDatas = new CharacterData[3];
            player.OverChargeDatas = new CardData[3];

            player.AccountId = avatar.AccountId;
            Hero geroin = null;
            for (int i = 0; i < 1; i++)
            {
                player.CharacterIds[i] = (home.CharacterId);

                Hero hero1 = avatar.GetHero(home.CharacterId);

                if (home.SelectedSkins[home.CharacterId - 16000000] > 0)
                {
                    player.SkinIds[i] = GlobalId.CreateGlobalId(29, home.SelectedSkins[home.CharacterId - 16000000]);
                }
               // player.StarPowerDatas[0] = (DataTables.Get(23).GetData<CardData>(avatar.GetHero(home.CharacterId).SelectedStarPowerId));
                player.CharacterDatas[0] = (DataTables.Get(DataType.Character).GetDataWithId<CharacterData>(home.CharacterId));
                geroin = avatar.GetHero(home.CharacterId);

                //CardData CardAccessoryData = DataTables.Get(23).GetDataByGlobalId<CardData>(GlobalId.CreateGlobalId(23, geroin.SelectedGadgetId));
                //if (CardAccessoryData != null)
                //{
                //    if (avatar.SPGS.Contains(CardAccessoryData.GetGlobalId()))
                //    {
                //        player.AccessoryCardDatas[0] = CardAccessoryData;
                //    }
                //}
                //if (player.AccessoryCardDatas[0] != null) player.AccessoryDatas[0] = DataTables.Get(DataType.Accessory).GetData<AccessoryData>(player.AccessoryCardDatas[0].Name);
                //else player.AccessoryDatas[0] = null;
            }


            //player.Accessory = player.AccessoryData == null ? null : new Accessory(player.AccessoryData);
            player.PlayerIndex = playerIndex;
            player.TeamIndex = teamIndex;
            Hero hero = avatar.GetHero(home.CharacterId);
            // player.Gear1 = DataTables.Get(DataType.Gear).GetDataWithId<GearData>(0);
            // player.Gear2 = DataTables.Get(DataType.Gear).GetDataWithId<GearData>(0);
            player.Trophies = hero.Trophies;
            player.HighestTrophies = hero.HighestTrophies;
            player.HeroPowerLevel = hero.PowerLevel;

            //player.GameListener = new LogicGameListener();
            //player.HeroIndex = 1;
            return player;
        }

        public static BattlePlayer CreateBotInfo(string name, int playerIndex, int teamIndex, int character = 16000000)
        {

            BattlePlayer player = new BattlePlayer();
            player.AccessoryCardDatas = new CardData[3];
            player.AccessoryDatas = new AccessoryData[3];
            player.StarPowerDatas = new CardData[3];
            player.CharacterDatas = new CharacterData[3];
            player.OverChargeDatas = new CardData[3];
            //player.AccessoryDatas[0] = DataTables.Get(DataType.Accessory).GetData<AccessoryData>("ShotgunGirl_Dash");
            player.AccessoryCardDatas[0] = DataTables.Get(23).GetData<CardData>("ShotgunGirl_Dash");
            //player.Accessory = new Accessory(player.AccessoryData);
            var rand = new Random();
            List<string> CreditsRandom = new List<string>{
                        "Brawler69",
                        "Hura2",
                        "XXmopsRR",
                        "Стас",
                        "Adinalovehardcorebdsmsperma12",
                        "898989",
                        "Браво Старс",
                        "Давид Дротян",
                        "Путь боксов хочу леона",
                        "Винтрейдеры гойда",
                        "Донатер",
                        "XXX_ProMakaka228",
                        "Zgbcmrf",
                        "XXX_EmoBoy",
                        "Тим со всеми без скама",
                        "Я не бот",
                        "Бот 10",
                        "zEr0bOr",
                        "НЕГР",
                        "Z",
                        "/give_me_spike",
                        "ЧИТЕР777",
                        "Райан Гослинг",
                        "крутой650",
                        "я думаю ты нуб",
                        "DungeonMaster",
                        "ЛГБТ СЕКС ИНСТРУКТОР",
                        "а4ЮЛЯ",
                        "GAMERBOY101",
                        "шщзпуаырщхшкпцргшщхупц",
                        "кек лол",
                        "Help Me",
                        "1000-7",
                        "А34",
                        "Gomogey",
                        "[Vi89]ViviVindenr",
                        "Негр89",
                        "Shadow",
"спидран 40 к",
"Крайм",
"волына",
"Мага",
"Vital Shark",
"hyra",
"дрочил на моль",
"Beast",
"мудила",
"Вампир Тампонов",
"злой Жека",
"FGX|MouDiLLa",
"zxcursed",
"ебен лох",
"Elite",
"Настикс",
"продам акк",
"Slushi",
"ева про",
"гоблин 2015",
"ем детей",
"Jenny Kitty",
"данечка",
"ФАнат НКеЯ",
"я лучшая мег",
"mainixx",
"феникс = мама ум",
"сухарики",
"орно",
"курю шишки",
"эскортница дима",
"au/aurum",
"navi/mma",
"лизал ли я?",
"QuinQue",
"Fronzzs",
"Noodle",
"Mr.Mister",
"JuaSassy",
"Gassik",
"Solo|Chagne",
"Terenze",
"Adorable Mio",
"дайджест Рон",
"кiтоныш",
"тролль пиэкки",
"Опухоль деда",
"Складочка мяу",
"бравлер",
"Dead Acidu",
"Shingi?",
"вирус бравл",
"1u1Maks",
"евы мудаки",
"хочешь меня?",
"дух победы",
"убил-гей",
"тренболон17",
"Жгуев Rave",
"IvanSolo",
"глиномес",
"рабопидарас",
"мега отец",
"шестерка",
"боевой",
"ревную к огурцу",
"кувалдин",
"Rigby",
"Midest",
"Torture",
"Freznt",
"мио стендоф",
"Инсерит",
"Криптанит",
"Вася Обломов",
"навигатор",
"роман кракен",
"Zlobny",
"Nunatona",
"4Kun4",
"Woody",
"Mico Main",
"Villain Arc",
"чертила",
"Cruella",
"Krohohaho",
"не тот рычаг",
"выжил 2022",
"Down Bass",
"сигма бой"};
            int CreditsRandomInt = rand.Next(CreditsRandom.Count);
            player.DisplayData.Name = CreditsRandom[CreditsRandomInt];
            player.DisplayData.ThumbnailId = GlobalId.CreateGlobalId(28, 0);
            player.DisplayData.NameColorId = GlobalId.CreateGlobalId(43, 0);
            player.DisplayData.HighNameColorId = GlobalId.CreateGlobalId(46, 0);
            player.AccountId = 100000 + playerIndex;
            player.CharacterIds[0] = (character);
            player.AccessoryCardDatas[0] = DataTables.Get(23).GetData<CardData>(255);
            // player.AccessoryDatas[0] = DataTables.Get(DataType.Accessory).GetData<AccessoryData>(player.AccessoryCardData.Name);
            //player.AccessoryUsesLeft = 3;
            player.PlayerIndex = playerIndex;
            player.TeamIndex = teamIndex;
            player.SessionId = -1;
            player.Bot = 1;
            player.CharacterDatas[0] = (DataTables.Get(DataType.Character).GetDataWithId<CharacterData>(character));

            player.SkinIds[0] = 0;
            player.HeroPowerLevel = new Random().Next(5, 9);
            player.HeroIndexMax = 0;
            return player;
        }
    }
}
