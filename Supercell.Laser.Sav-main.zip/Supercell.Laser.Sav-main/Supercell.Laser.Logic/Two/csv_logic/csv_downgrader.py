import csv
from pathlib import Path

# Authors: @xmopser and CHINA AIIII DEEEPPPSIIEAAAKKK
# use = + 10000000 SOCIAL RATING!!!!

def transfer_csv_rows(source_path, target_path, output_path, chunk_size=10000):
    """
    Переносит строки из source CSV в target CSV, сохраняя только совпадающие колонки.
    Обрабатывает файлы по частям для работы с большими файлами.
    
    :param source_path: Путь к исходному CSV файлу
    :param target_path: Путь к целевому CSV файлу (для определения структуры)
    :param output_path: Путь для сохранения результата
    :param chunk_size: Количество строк для обработки за один раз
    """
    # Определяем колонки в целевом файле
    with open(target_path, 'r', newline='', encoding='utf-8') as target_file:
        target_reader = csv.DictReader(target_file)
        target_fields = target_reader.fieldnames
    
    # Открываем исходный файл и создаем выходной
    with (open(source_path, 'r', newline='', encoding='utf-8') as source_file,
          open(output_path, 'w', newline='', encoding='utf-8') as out_file):
        
        source_reader = csv.DictReader(source_file)
        source_fields = source_reader.fieldnames
        
        # Определяем пересекающиеся колонки (в порядке целевого файла)
        common_fields = [field for field in target_fields if field in source_fields]
        
        writer = csv.DictWriter(out_file, fieldnames=target_fields)
        writer.writeheader()
        
        # Обрабатываем исходный файл по частям
        while True:
            chunk = []
            try:
                for _ in range(chunk_size):
                    row = next(source_reader)
                    # Создаем новую строку только с общими полями
                    new_row = {field: row[field] for field in common_fields if field in row}
                    chunk.append(new_row)
            except StopIteration:
                if not chunk:
                    break
            
            # Записываем чанк в выходной файл
            writer.writerows(chunk)
            print(f"Обработано {len(chunk)} строк...")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Перенос строк между CSV файлами с совпадающими колонками")
    parser.add_argument("source", help="Исходный CSV файл")
    parser.add_argument("target", help="Целевой CSV файл (для структуры)")
    parser.add_argument("output", help="Выходной CSV файл")
    parser.add_argument("--chunk", type=int, default=10000, help="Размер чанка для обработки (по умолчанию 10000)")
    
    args = parser.parse_args()
    
    print(f"Перенос данных из {args.source} в {args.output} по структуре {args.target}")
    transfer_csv_rows(args.source, args.target, args.output, args.chunk)
    import os
    os.remove(f"{args.source}")
    os.remove(f"{args.target}")
    print("Готово!")