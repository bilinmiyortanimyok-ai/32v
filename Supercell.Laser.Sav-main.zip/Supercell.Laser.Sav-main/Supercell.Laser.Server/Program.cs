﻿namespace Supercell.Laser.Server
{
    using Supercell.Laser.Server.Handler;
    using Supercell.Laser.Server.Settings;
    using System.Drawing;
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.Text;
    using System.Text.Json;
    using Supercell.Laser.Server.Utils;

    static class Program
    {
        public static string SERVER_VERSION;
        public static int BattlesCompleted;

        private static void Main(string[] args)
        {
            Directory.SetCurrentDirectory(AppContext.BaseDirectory);

            Colorful.Console.WriteWithGradient(
                @"
    ____                      __   _____ __                 
   / __ )_________ __      __/ /  / ___// /_____ ___________
  / __  / ___/ __ `/ | /| / / /   \__ \/ __/ __ `/ ___/ ___/
 / /_/ / /  / /_/ /| |/ |/ / /   ___/ / /_/ /_/ / /  (__  ) 
/_____/_/   \__,_/ |__/|__/_/   /____/\__/\__,_/_/  /____/  
                                                            
       " + "\n\n\n", Color.Fuchsia, Color.Cyan, 8);

            Logger.Init();
            ServerDataStore.Init();
            SERVER_VERSION = ServerDataStore.GetServerVersion();
            BattlesCompleted = ServerDataStore.GetBattlesCompletedCount();
            Console.Title = $"Supercell.Laser.Server - {SERVER_VERSION}";
            Configuration.Instance = Configuration.LoadFromFile("config.json");

            Resources.InitDatabase();
            Resources.InitLogic();
            Resources.InitNetwork();

            Logger.Print("Server started! Let's play Brawl Stars!");

            ExitHandler.Init();
            CmdHandler.Start();
        }
    }
}
