namespace Supercell.Laser.Server.Logic
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class PromocodeData
    {
        [JsonProperty("promoName")]
        public string promoName { get; set; }

        [JsonProperty("promoProduct")]
        public string promoProduct { get; set; }

        [JsonProperty("promoProductCount")]
        public string promoProductCount { get; set; }

        [JsonProperty("promoLimitActivation")]
        public int promoLimitActivation { get; set; }

        [JsonProperty("promoActivations")]
        public List<long> promoActivations { get; set; } = new List<long>();
    }

    public static class Promocodes
    {
        private static List<PromocodeData> _promocodes = new List<PromocodeData>();
        private static string _filePath = "promo.json";

        public static void Init()
        {
            LoadFromFile();
        }

        private static void LoadFromFile()
        {
                if (!File.Exists(_filePath))
                {
                    Console.WriteLine("[PROMO] promo.json not found!");
                    return;
                }

                string json = File.ReadAllText(_filePath);
                JObject jObject = JObject.Parse(json);
                JArray promocodes = jObject["codes"] as JArray;

                _promocodes.Clear();
                foreach (var promo in promocodes)
                {
                    PromocodeData data = promo.ToObject<PromocodeData>();
                    _promocodes.Add(data);
                }

                Console.WriteLine($"[PROMO] Loaded {_promocodes.Count} promocodes");
        }

        public static PromocodeData GetPromocode(string code)
        {
            return _promocodes.FirstOrDefault(p => p.promoName.Equals(code, StringComparison.OrdinalIgnoreCase));
        }

        public static bool ActivatePromocode(string code, long accountId)
        {
            PromocodeData promo = GetPromocode(code);
            if (promo == null)
            {
                return false;
            }

            if (promo.promoActivations.Contains(accountId))
            {
                return false;
            }

            if (promo.promoActivations.Count >= promo.promoLimitActivation)
            {
                return false;
            }

            promo.promoActivations.Add(accountId);
            SaveToFile();
            return true;
        }

        private static void SaveToFile()
        {
            try
            {
                JObject jObject = new JObject();
                JArray promocodes = new JArray();

                foreach (var promo in _promocodes)
                {
                    promocodes.Add(JObject.FromObject(promo));
                }

                jObject["codes"] = promocodes;
                File.WriteAllText(_filePath, jObject.ToString(Formatting.Indented));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROMO] Ошибка при сохранении промокодов: {ex.Message}");
            }
        }

        public static int GetActivationCount(string code)
        {
            PromocodeData promo = GetPromocode(code);
            return promo?.promoActivations.Count ?? 0;
        }
    }
}
