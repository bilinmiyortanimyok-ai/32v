﻿namespace Supercell.Laser.Server.Logic.Game
{
    using Newtonsoft.Json;
    using Supercell.Laser.Logic.Club;
    using Supercell.Laser.Server.Database.Models;
    using Supercell.Laser.Server.Networking.Session;
    using System.Text;

    public class DataEntry
    {
        public DateTime Time { get; set; }
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Populate)]
        public int Online { get; set; }
    }

    public class DataContainer
    {
        public List<DataEntry> Data { get; set; }
    }

    public static class Leaderboards
    {
        private static List<Account> Accounts;
        private static List<Alliance> Alliances;
        private static Dictionary<int, List<Account>> Brawlers;
        private static Thread Thread;
        private static int timeg;

        private static StringBuilder FileLogger;

        public static void Init()
        {
            Accounts = new List<Account>();
            Alliances = new List<Alliance>();
            Brawlers = new Dictionary<int, List<Account>>();

            Thread = new Thread(Update);
            Thread.Start();
            FileLogger = new();
        }

        public static Account[] GetAvatarRankingList()
        {
            return Accounts.ToArray();
        }

        public static Dictionary<int, List<Account>> GetBrawlersRankingList()
        {
            return Brawlers;
        }

        public static Alliance[] GetAllianceRankingList()
        {
            return Alliances.ToArray();
        }

        private static void Update()
        {
            while (true)
            {
                Accounts = new List<Account>();
                Alliances = new List<Alliance>();
                Brawlers = new Dictionary<int, List<Account>>();
                Accounts = Database.Accounts.GetRankingList();
                Alliances = Database.Alliances.GetRankingList();
                Brawlers = Database.Accounts.GetBrawlersRankingList();
                Thread.Sleep(1000 * 30 * 10);
            }
        }
    }
}
