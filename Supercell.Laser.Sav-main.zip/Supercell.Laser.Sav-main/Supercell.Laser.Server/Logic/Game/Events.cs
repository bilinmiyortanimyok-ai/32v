﻿namespace Supercell.Laser.Server.Logic.Game
{
    using Supercell.Laser.Logic.Data;
    using Supercell.Laser.Logic.Home.Items;
    using Supercell.Laser.Server.Database;
    using Supercell.Laser.Titan.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using Supercell.Laser.Logic.Command.Home;
    using Supercell.Laser.Logic.Message.Home;
    using Supercell.Laser.Server.Networking.Session;
    using EventData = Supercell.Laser.Logic.Home.Items.EventData;
    using System.Configuration;
    using Supercell.Laser.Logic.Data.Helper;

    public static class Events
    {
        public const int REFRESH_MINUTES = 120;

        private static Timer RefreshTimer;
        private static EventSlotConfig[] ConfigSlots;
        private static Dictionary<int, EventData> Slots;
        private static Dictionary<int, List<long>> SlotsCollected = new();

        private static DateTime GetMSKTimeToRefresh(string gameMode)
        {
            int hour = gameMode switch
            {
                "Bounty" or "Heist" => 17,
                "Showdown" or "DuoShowdown" => 0,
                "GemGrab" => 12,
                "KingOfHill" => 22,
                "BigGame" => 0,
                "HoldTheBall" => 0,
                "BasketBrawl" => 0,
                "VolleyBrawl" => 0,
                "BrawlBall" => 0,
                "ProtectKing" => 0,
                "Payload" => 0,
                "Invasion" => 0,
                "TagTeam" => 0,
                "BossFight_TownCrush" => 0,
                "CTF" => 0,
                _ => 4
            };

            TimeZoneInfo mskZone = TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time");
            DateTime mskNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, mskZone);
            DateTime targetTimeToday = new DateTime(mskNow.Year, mskNow.Month, mskNow.Day, hour, 0, 0);

            if (mskNow >= targetTimeToday)
            {
                targetTimeToday = targetTimeToday.AddDays(1);
            }

            return targetTimeToday;
        }

        public static void Init()
        {
            LoadSettings();
            Slots = new Dictionary<int, EventData>();
            GenerateEvents();

            RefreshTimer = new Timer(CheckEventsRefresh, null, TimeSpan.Zero, TimeSpan.FromMinutes(0.1));
        }

        private static void CheckEventsRefresh(object state)
        {
            try
            {
                DateTime now = DateTime.UtcNow;

                foreach (var config in ConfigSlots)
                {
                    if (!Slots.TryGetValue(config.Slot, out var currentEvent))
                    {
                        RegenerateSlot(config);
                        continue;
                    }

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"error refreshing events: {ex}");
            }
        }

        private static void GenerateEvents()
        {
            foreach (var config in ConfigSlots)
            {
                Slots[config.Slot] = GenerateEvent(config.AllowedModes, config.Slot, config.location, config.Locations, config.modifi);
            }
        }

        private static void RegenerateSlot(EventSlotConfig config)
        {
            var newEvent = GenerateEvent(config.AllowedModes, config.Slot, config.location, config.Locations, config.modifi);
            if (newEvent == null) return;

            Slots[config.Slot] = newEvent;
            //Matchmaking.ReloadSlot(config.Slot, newEvent);
            NotifyPlayers();
        }

        private static void NotifyPlayers()
        {
           
        }

        private static EventData GenerateEvent(string[] gameModes, int slot, int presetlocation, List<int> presetLocations, HashSet<int> modifi)
        {
            LocationData location = null;

            if (presetLocations != null && presetLocations.Count > 0)
            {
                Random rand = new Random();
                int tries = 0;
                while (tries < presetLocations.Count && location == null)
                {
                    int locationId = presetLocations[rand.Next(0, presetLocations.Count)];
                    location = DataTables.Get(DataType.Location).GetDataWithId<LocationData>(locationId);
                    tries++;
                }

                if (location == null)
                {
                    foreach (int locationId in presetLocations)
                    {
                        location = DataTables.Get(DataType.Location).GetDataWithId<LocationData>(locationId);
                        if (location != null) break;
                    }
                }

                if (location == null)
                {
                    Console.WriteLine($"preset locations for slot {slot} not found!");
                    return null;
                }
            }
            else if (presetlocation != 0)
            {
                location = DataTables.Get(DataType.Location).GetDataWithId<LocationData>(presetlocation);
                if (location == null)
                {
                    Console.WriteLine($"preset location {presetlocation} not found!");
                    return null;
                }
            }
            else
            {
                int count = 1;
                Random rand = new Random();
                int tries = 0;
                while (tries < 1000 && location == null)
                {
                    var potentialLocation = DataTables.Get(DataType.Location).GetDataWithId<LocationData>(rand.Next(0, count));
                    location = potentialLocation;
                    tries++;
                }

                if (location == null)
                {
                    tries = 0;
                    while (tries < 1000 && location == null)
                    {
                        var potentialLocation = DataTables.Get(DataType.Location).GetDataWithId<LocationData>(rand.Next(0, count));
                        location = potentialLocation;
                        tries++;
                    }
                }
            }

            if (location == null)
            {
                Console.WriteLine($" slot not found {slot}");
                return new EventData
                {
                    Slot = slot,
                    LocationId = GlobalId.CreateGlobalId(15, 14),
                    EndTime = TimeZoneInfo.ConvertTimeToUtc(GetMSKTimeToRefresh(location.GameMode), TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time")),
                };
            }

            DateTime refreshTime = GetMSKTimeToRefresh(location.GameMode);
            DateTime refreshTimeUTC = TimeZoneInfo.ConvertTimeToUtc(refreshTime, TimeZoneInfo.FindSystemTimeZoneById("Russian Standard Time"));

            SlotsCollected.Add(slot, new List<long>());

            return new EventData
            {
                Slot = slot,
                LocationId = location.GetGlobalId(),
                EndTime = refreshTimeUTC,
            };
        }

        private static void LoadSettings()
        {
            LogicJSONObject settings = LogicJSONParser.ParseObject(File.ReadAllText("gameplay.json"));
            LogicJSONArray slots = settings.GetJSONArray("slots");
            ConfigSlots = new EventSlotConfig[slots.Size()];

            for (int i = 0; i < slots.Size(); i++)
            {
                EventSlotConfig config = new EventSlotConfig();

                LogicJSONObject slot = slots.GetJSONObject(i);
                config.Slot = slot.GetJSONNumber("slot").GetIntValue();

                LogicJSONArray gameModes = slot.GetJSONArray("game_modes");
                LogicJSONArray locations = slot.GetJSONArray("locations");
                LogicJSONArray modifi = slot.GetJSONArray("modificators");
                config.AllowedModes = new string[gameModes.Size()];
                if (locations != null && locations.Size() > 0)
                {
                    for (int l = 0; l < locations.Size(); l++)
                    {
                        LogicJSONNumber locationNode = locations.GetJSONNumber(l);

                        if (locationNode != null)
                            config.Locations.Add(locationNode.GetIntValue());
                    }
                }
                else
                {
                    LogicJSONNumber locationNode = slot.GetJSONNumber("location");

                    if (locationNode != null)
                        config.location = locationNode.GetIntValue();
                }
                for (int j = 0; j < gameModes.Size(); j++)
                {
                    config.AllowedModes[j] = gameModes.GetJSONString(j).GetStringValue();
                }
                if (modifi != null)
                {
                    for (int k = 0; k < modifi.Size(); k++)
                    {
                        LogicJSONNumber numberNode = modifi.GetJSONNumber(k);

                        if (numberNode != null)
                            config.modifi.Add(numberNode.GetIntValue());
                    }
                }
                ConfigSlots[i] = config;
            }
        }

        public static EventData[] GetEventsById(int a, long id)
        {
            try
            {
                EventData[] events = Slots.Values.ToArray();
                int index = 0;
                foreach (EventData e in events)
                {
                    if (SlotsCollected[e.Slot].Contains(id))
                    {
                        e.IsBonusCollected = true;
                    }
                    else
                    {
                        e.IsBonusCollected = false;
                    }
                    e.PowerPlayGamesPlayed = a;
                    events[index] = e;
                    index++;
                }
                return events;
            }
            catch
            {
                return Slots.Values.ToArray();
            }
        }

        public static bool CollectEvent(long id, int slot)
        {
            if (!HasSlot(slot)) return false;
            if (SlotsCollected[slot].Contains(id)) return false;
            SlotsCollected[slot].Add(id);
            //Slots[slot].IsNewEvent = false;
            return true;
        }

        public static EventData GetEvent(int slot) => Slots.TryGetValue(slot, out var eventData) ? eventData : null;
        public static bool HasSlot(int slot) => Slots.ContainsKey(slot);
        public static EventData[] GetEvents() => Slots.Values.ToArray();

        private class EventSlotConfig
        {
            public int Slot { get; set; }
            public string[] AllowedModes { get; set; }
            public int location;
            public List<int> Locations = new();

            public HashSet<int> modifi = new();
        }
        private class ServerEventData
        {
            public int Slot { get; set; }
            public int LocationId { get; set; }
            public DateTime EndTime { get; set; }
        }
    }
}
